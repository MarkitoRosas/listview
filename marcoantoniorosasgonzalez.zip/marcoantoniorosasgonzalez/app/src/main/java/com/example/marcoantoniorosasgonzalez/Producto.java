package com.example.marcoantoniorosasgonzalez;

public class Producto {
    //propiedades
    private String nombre;
    private int imagen;
    private String descripcion;
    private String descripcion1;


    //constructor
    public Producto(String nombre, int imagen,String precio, String oferta){
        this.nombre = nombre;
        this.imagen = imagen;
        this.descripcion = descripcion;
        this.descripcion1= descripcion1;
    }
    public String getNombre() {
        return nombre;
    }

    public int getImagen() {
        return imagen;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getDescripcion1() {
        return descripcion1;
    }
}
