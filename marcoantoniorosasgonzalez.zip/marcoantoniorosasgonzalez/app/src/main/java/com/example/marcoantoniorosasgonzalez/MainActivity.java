package com.example.marcoantoniorosasgonzalez;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Producto> listaProducto;
    private ProductosAdapter productosAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaProducto = new ArrayList<>();
        listaProducto.add(new Producto("Conexiones",R.drawable.ic_baseline_wifi_24," ","wifi,bluetooth,perfil fuera de linea,uso de datos"));
        listaProducto.add(new Producto( "sonido y vribracion",R.drawable.ic_baseline_volume_up_24," ","modo de sonido,tono de llamada"));
        listaProducto.add(new Producto("notificaciones",R.drawable.ic_baseline_notifications_24," ", "notificaciones,barra de estado"));
        listaProducto.add(new Producto("pantalla",R.drawable.ic_baseline_wb_sunny_24," ", "brillo,filtro de luz,pantalla de luz"));
        listaProducto.add(new Producto("fondo de oantalla",R.drawable.ic_baseline_image_24, " ","brillo,filtro de luz azul,pantalla de inicio"));
        listaProducto.add(new Producto("temas",R.drawable.ic_baseline_brush_24," ","temas,fondo de pantalla"));
        listaProducto.add(new Producto("datos biometricos y seguridad",R.drawable.ic_baseline_lock_24," ","reconocimioento facial, huellas digitales"));
        listaProducto.add(new Producto("ubicacion",R.drawable.ic_baseline_my_location_24," ","ajustes de ubicacion"));
        listaProducto.add(new Producto("actualizacion de software",R.drawable.ic_baseline_cloud_24," ","descargar actualizaciones"));



        productosAdapter = new ProductosAdapter(getApplicationContext(),0, listaProducto);
        ListView listView = findViewById(R.id.listViewProducto);
        listView.setAdapter(productosAdapter);
    }
}